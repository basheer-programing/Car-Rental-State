import { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './css-pages/Homepage.css';

const Homepage = () => {
    const [featuredCars, setFeaturedCars] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchFeaturedCars = async () => {
            setLoading(true);
            setError(null);

            try {
                const response = await axios.get('http://127.0.0.1:8000/api/cars');
                console.log('API Response:', response.data);

                if (Array.isArray(response.data.data)) {
                    setFeaturedCars(response.data.data);
                } else {
                    throw new Error('Unexpected response format');
                }
            } catch (error) {
                console.error('Error fetching featured cars:', error);
                if (error.response) {
                    console.error('Response data:', error.response.data);
                    console.error('Response status:', error.response.status);
                    console.error('Response headers:', error.response.headers);
                } else if (error.request) {
                    console.error('No response received:', error.request);
                } else {
                    console.error('Error:', error.message);
                }
                setError('Failed to fetch featured cars');
            } finally {
                setLoading(false);
            }
        };

        fetchFeaturedCars();
    }, []);

    if (loading) {
        return <div>Loading...</div>;
    }

    if (error) {
        return <div style={{ color: 'red' }}>{error}</div>;
    }

    return (
        <div className="homepage-container">
            <header>
                <h1>Welcome to the Car Rental Service</h1>
                <p>Your reliable partner for car rentals</p>
                <div className="homepage-links">
                    <Link to="/reservation" className="homepage-reservation-link">Go to Reservation Page</Link>
                </div>
            </header>

            <section className="features">
                <h2>Featured Cars</h2>
                <div className="car-cards">
                    {featuredCars.map((car) => (
                        <Link to="/reservation" key={car.id} className="car-card">
                            <img src={car.image} alt={`Car ${car.model}`} />
                            <h3>{car.model}</h3>
                            <p>Starting at ${car.daily_price}/day</p>
                        </Link>
                    ))}
                </div>
            </section>
            <section className="cta">
                <h2>Ready to make a reservation?</h2>
                <Link to="/search" className="cta-button">Browse Available Cars</Link>
            </section>
        </div>
    );
};

export default Homepage;