import  { useState, useEffect } from 'react';
import './css-pages/AdminDashboard.css';
import { Link } from 'react-router-dom';

const AdminDashboard = () => {
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [error, setError] = useState('');
    const [credentials, setCredentials] = useState({ username: '', password: '' });

    // تحقق من حالة تسجيل الدخول عند تحميل المكون
    useEffect(() => {
        const loggedInStatus = localStorage.getItem('isLoggedIn');
        if (loggedInStatus === 'true') {
            setIsLoggedIn(true);
        }
    }, []);

    const handleLogin = () => {
        const { username, password } = credentials;
        // مثال للتحقق من بيانات الدخول
        if (username === 'admin' && password === 'password123') {
            setIsLoggedIn(true);
            setError('');
            // حفظ حالة تسجيل الدخول في localStorage
            localStorage.setItem('isLoggedIn', 'true');
        } else {
            setError('Invalid username or password.');
        }
    };

    const handleLogout = () => {
        setIsLoggedIn(false);
        // إزالة حالة تسجيل الدخول من localStorage
        localStorage.removeItem('isLoggedIn');
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setCredentials({ ...credentials, [name]: value });
    };

    return (
        <div className="admin-dashboard">
            {!isLoggedIn ? (
                <div className="login-form">
                    <h2>Admin Login</h2>
                    {error && <p className="error-message">{error}</p>}
                    <input
                        type="text"
                        name="username"
                        placeholder="Username"
                        value={credentials.username}
                        onChange={handleChange}
                        className="input-field"
                    />
                    <input
                        type="password"
                        name="password"
                        placeholder="Password"
                        value={credentials.password}
                        onChange={handleChange}
                        className="input-field"
                    />
                    <button onClick={handleLogin} className="login-button">Login</button>
                </div>
            ) : (
                <>
                    <h1 className="newh1">Admin Dashboard</h1>
                    <div className="admin-links-container">
                        <Link to="/" className="admin-link">Go to Homepage</Link>
                        <Link to="/add-car" className="admin-link">Add New Cars</Link>
                        <Link to="/view-cars" className="admin-link">View Cars</Link>
                        <Link to="/manage-rentals" className="admin-link">Manage Rentals</Link>
                        <Link to="/manage-customers" className="admin-link">Manage Customers</Link>
                        <Link to="/reports" className="admin-link">Reports & Statistics</Link>
                        <Link to="/create-report" className="admin-link">Create Rental Revenue Report</Link>
                        <button onClick={handleLogout} className="logout-button">Logout</button>
                    </div>
                </>
            )}
        </div>
    );
};

export default AdminDashboard;