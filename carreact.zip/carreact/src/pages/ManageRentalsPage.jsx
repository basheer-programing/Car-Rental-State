import  { useEffect, useState } from 'react';
import axios from 'axios';
import './css-pages/ManageRentalspage.css';

const ManageRentalsPage = () => {
  const [rentals, setRentals] = useState([]);

  // جلب بيانات الحجوزات
  useEffect(() => {
    fetchRentals();
  }, []);

  const fetchRentals = async () => {
    try {
      const response = await axios.get('http://localhost:8000/api/bookings'); // استخدم رابط الـ API الخاص بك
      setRentals(response.data);
    } catch (error) {
      console.error("Error fetching rentals:", error);
    }
  };

  // التعامل مع حذف الحجز
  const handleDelete = async (id) => {
    if (window.confirm('هل أنت متأكد من حذف هذا الحجز؟')) {
      try {
        await axios.delete(`http://localhost:8000/api/bookings/${id}`);
        fetchRentals(); // إعادة تحميل البيانات بعد الحذف
        alert('تم الحذف بنجاح');
      } catch (error) {
        console.error("Error deleting rental:", error);
      }
    }
  };

  // التعامل مع تعديل الحجز
  const handleEdit = (id) => {
    window.location.href = `/bookings/edit/${id}`; // توجيه المستخدم إلى صفحة التعديل
  };

  return (
    <div className="manage-rentals-page">
      <h1 className="newh1">Manage Car Rentals</h1>
      <table className="rentals-table">
        <thead>
          <tr>
            <th>رقم الحجز</th>
            <th>اسم المستخدم</th>
            <th>اسم السيارة</th>
            <th>تاريخ البداية</th>
            <th>تاريخ النهاية</th>
            <th>الموقع</th>
            <th>الحالة</th>
            <th>العمليات</th>
          </tr>
        </thead>
        <tbody>
          {rentals.map((rental) => (
            <tr key={rental.id}>
              <td>{rental.id}</td>
              <td>{rental.user.name}</td> {/* تأكد من أن اسم المستخدم موجود في البيانات */}
              <td>{rental.car.model}</td> {/* تأكد من أن اسم السيارة موجود */}
              <td>{rental.start_date}</td>
              <td>{rental.end_date}</td>
              <td>{rental.location}</td>
              <td>{rental.status}</td>
              <td>
           
                <button
                  className="delete-button"
                  onClick={() => handleDelete(rental.id)}
                >
                  حذف
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ManageRentalsPage;
