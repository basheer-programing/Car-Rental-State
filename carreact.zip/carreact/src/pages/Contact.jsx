import React from "react";
import "./css-pages/About and Contact.css";

const Contact = () => {
    return (
        <div className="contact-page">
            <h1 className="ac">Contact Us</h1>
            <p className="acp">If you have any inquiries, please feel free to reach out!</p>

            <div className="contact-links">
                {/* رابط الهاتف */}
                <a href="tel:+1234567890" className="contact-link">
                    <i className="fas fa-phone"></i> Call Us: +1234567890
                </a>

                {/* رابط واتساب */}
                <a href="https://wa.me/1234567890" target="_blank" rel="noopener noreferrer" className="contact-link">
                    <i className="fab fa-whatsapp"></i> Chat on WhatsApp
                </a>

                {/* رابط فيسبوك */}
                <a href="https://www.facebook.com/yourpage" target="_blank" rel="noopener noreferrer" className="contact-link">
                    <i className="fab fa-facebook"></i> Visit us on Facebook
                </a>
            </div>
        </div>
    );
};

export default Contact;