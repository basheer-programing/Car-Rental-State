import React from 'react';
import './css-pages/ReportsPage.css';

const ReportsPage = () => {
  const reportsData = [
    { title: "Monthly Revenue", value: "$25,000", growth: "+15%", trend: "up" },
    { title: "New Users", value: "1,200", growth: "+10%", trend: "up" },
    { title: "Customer Satisfaction", value: "89%", growth: "-2%", trend: "down" },
  ];

  const renderReportCard = (report) => (
    <div className={`report-card trend-${report.trend}`} key={report.title}>
      <h2>{report.title}</h2>
      <p className="value">{report.value}</p>
      <p className="growth">
        {report.growth} {report.trend === "up" ? "📈" : "📉"}
      </p>
    </div>
  );

  return (
    <div className="reports-container">
      <h1>Reports & Statistics</h1>
      <p>Analyze your performance metrics and trends below:</p>
      <div className="reports-grid">
        {reportsData.map(renderReportCard)}
      </div>
    </div>
  );
};

export default ReportsPage;
