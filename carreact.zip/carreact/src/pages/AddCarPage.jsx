import  { useState } from 'react';
import axios from 'axios';
import './css-pages/AddCarPage.css';

const AddCarPage = () => {
    const [carDetails, setCarDetails] = useState({
        model: '',
        year: '',
        color: '',
        features: '',
        seats: '',
        status: '',
        location: '',
        daily_price: '',
        image: null,
    });

    const [errors, setErrors] = useState({});
    const [isLoading, setIsLoading] = useState(false);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setCarDetails((prevDetails) => ({
            ...prevDetails,
            [name]: value,
        }));
    };

    const handleImageChange = (e) => {
        const file = e.target.files[0];
        setCarDetails((prevDetails) => ({
            ...prevDetails,
            image: file, // تخزين الملف في الـ state
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsLoading(true);

        const formData = new FormData();
        formData.append('model', carDetails.model);
        formData.append('year', carDetails.year);
        formData.append('color', carDetails.color);
        formData.append('features', carDetails.features);
        formData.append('seats', carDetails.seats);
        formData.append('status', carDetails.status);
        formData.append('location', carDetails.location);
        formData.append('daily_price', carDetails.daily_price);
        if (carDetails.image) {
            formData.append('image', carDetails.image); // إضافة الصورة فقط إذا كانت موجودة
        }

        try {
            const response = await axios.post('http://localhost:8000/api/cars', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });

            alert(response.data.message);
            setErrors({});
            setCarDetails({
                model: '',
                year: '',
                color: '',
                features: '',
                seats: '',
                status: '',
                location: '',
                daily_price: '',
                image: null,
            });
        } catch (error) {
            if (error.response && error.response.data.errors) {
                setErrors(error.response.data.errors);
            }
            alert('Failed to add car: ' + (error.response?.data?.message || 'Unknown error'));
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="add-car-page">
            <h1 className="newhh">Add New Car</h1>
            <form className="add-car-form" onSubmit={handleSubmit}>
                <input type="text" name="model" placeholder="Car Model" value={carDetails.model} onChange={handleInputChange} className="input-field" required />
                {errors.model && <p className="error">{errors.model[0]}</p>}

                <input type="number" name="year" placeholder="Year" value={carDetails.year} onChange={handleInputChange} className="input-field" required />
                {errors.year && <p className="error">{errors.year[0]}</p>}

                <input type="text" name="color" placeholder="Color" value={carDetails.color} onChange={handleInputChange} className="input-field" required />
                {errors.color && <p className="error">{errors.color[0]}</p>}

                <textarea name="features" placeholder="Features (comma-separated)" value={carDetails.features} onChange={handleInputChange} className="input-field" rows="3" required />
                {errors.features && <p className="error">{errors.features[0]}</p>}

                <input type="number" name="seats" placeholder="Number of Seats" value={carDetails.seats} onChange={handleInputChange} className="input-field" required />
                {errors.seats && <p className="error">{errors.seats[0]}</p>}

                <input type="text" name="status" placeholder="Status" value={carDetails.status} onChange={handleInputChange} className="input-field" required />
                {errors.status && <p className="error">{errors.status[0]}</p>}

                <input type="text" name="location" placeholder="Location" value={carDetails.location} onChange={handleInputChange} className="input-field" required />
                {errors.location && <p className="error">{errors.location[0]}</p>}

                <input type="number" name="daily_price" placeholder="Daily Price" value={carDetails.daily_price} onChange={handleInputChange} className="input-field" required />
                {errors.daily_price && <p className="error">{errors.daily_price[0]}</p>}

                <input type="url" name="image" onChange={handleImageChange} className="input-field"  placeholder="Add Url Image from web "/>
                {errors.image && <p className="error">{errors.image[0]}</p>}

                <button type="submit" className="submit-button" disabled={isLoading}>
                    {isLoading ? 'Adding Car...' : 'Add Car'}
                </button>
            </form>
        </div>
    );
};

export default AddCarPage;
