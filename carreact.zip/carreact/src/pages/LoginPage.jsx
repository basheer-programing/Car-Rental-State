// LoginPage Component 
import  { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../components/context/AuthContext'; // Import useAuth
import axios from 'axios'; // Import axios for API calls

import './css-pages/LoginPage.css';  // Make sure to create the corresponding CSS file to style the page


const LoginPage = () => {
    const { login, logout } = useAuth(); // Import login and logout from auth context
    const navigate = useNavigate();

    const [formData, setFormData] = useState({ email: '', password: '' }); // Initialize form data state
    const [loading, setLoading] = useState(false); // Initialize loading state
    const [error, setError] = useState(null); // Initialize error state

    const handleChange = (e) => {
        setFormData((prevFormData) => ({ ...prevFormData, [e.target.name]: e.target.value }));
    };

    const handleLogin = async (e) => {
        e.preventDefault();
        setLoading(true); // Set loading to true
        setError(null); // Clear error

        try {
            const response = await axios.post('http://localhost:8000/api/login', formData); // Replace with your API URL

            if (response.status === 200) {
                login(response.data.id); // Use user ID returned from API
                navigate('/'); // Redirect after successful login
            } else {
                setError('Failed to login'); // Set error message
            }
        } catch (error) {
            setError('Failed to login'); // Set error message
        } finally {
            setLoading(false); // Set loading to false
        }
    };

    return (
        <div className="login-container">
            <h2>Login</h2>
            <form onSubmit={handleLogin}>
                <div className="form-group">
                    <label htmlFor="email">Email</label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="password">Password</label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        required
                    />
                </div>
                {loading ? (
                    <button type="submit" disabled>
                        Loading...
                    </button>
                ) : (
                    <button type="submit">Login</button>
                )}
                {error && <p style={{ color: 'red' }}>{error}</p>}
            </form>
            <button onClick={() => logout()} className="logout-btn" style={{ display: 'none' }}>
                Logout
            </button>
        </div>
    );
};

export default LoginPage;