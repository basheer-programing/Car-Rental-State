import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ManageCustomersPage = () => {
    const [customers, setCustomers] = useState([]); // حالة لتخزين قائمة المستخدمين
    const [isLoading, setIsLoading] = useState(true); // حالة لتحميل البيانات
    const [error, setError] = useState(null); // حالة لتخزين الأخطاء

    useEffect(() => {
        fetchCustomers();
    }, []);

    const fetchCustomers = async () => {
        try {
            // إرسال طلب GET إلى API لاسترجاع جميع المستخدمين
            const response = await axios.get('http://localhost:8000/api/users');
            setCustomers(response.data); // تعيين البيانات المسترجعة إلى الحالة
        } catch (error) {
            console.error('Error fetching customers:', error);
            setError('Failed to fetch customers data.');
        } finally {
            setIsLoading(false);
        }
    };

    if (isLoading) {
        return <p>Loading customers data...</p>;
    }

    if (error) {
        return <p>Error: {error}</p>;
    }

    return (
        <div>
            <h1>Manage Customers</h1>
            {customers.length > 0 ? (
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Address</th>
                            <th>License Number</th>
                        </tr>
                    </thead>
                    <tbody>
                        {customers.map((customer) => (
                            <tr key={customer.id}>
                                <td>{customer.name}</td>
                                <td>{customer.email}</td>
                                <td>{customer.phone}</td>
                                <td>{customer.address}</td>
                                <td>{customer.license_number}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            ) : (
                <p>No customers found.</p>
            )}
        </div>
    );
};

export default ManageCustomersPage;