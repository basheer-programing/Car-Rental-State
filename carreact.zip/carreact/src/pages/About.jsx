// About.js
import React from "react";
import "./css-pages/About and Contact.css";

const About = () => {
    return (
        <div className="about-page">
            <h1 class="ac">About Us</h1>
            <p class="acp">
                Welcome to our car rental management system! We strive to provide efficient and reliable solutions for managing car rentals, customer data, and much more. Our mission is to empower businesses with easy-to-use tools and innovative features.
            </p>
            <p class="acp">
                If you have any questions or feedback, feel free to reach out through our contact page. We are here to help!
            </p>
        </div>
    );
};

export default About;
