import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './css-pages/SignupPage.css';

const SignupPage = () => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        password: '',
        phone: '',
        address: '',
        license_number: '',
        license_image: ''
    });
    const [errors, setErrors] = useState({}); // حالة لتخزين أخطاء التحقق
    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrors({}); // إعادة تعيين أخطاء التحقق

        try {
            const csrfMetaTag = document.querySelector('meta[name="csrf-token"]');
            const csrfToken = csrfMetaTag ? csrfMetaTag.getAttribute('content') : '';

            const response = await fetch('http://localhost:8000/api/signup', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken,
                },
                body: JSON.stringify(formData),
            });

            if (!response.ok) {
                const errorResponse = await response.json();
                if (errorResponse.errors) {
                    setErrors(errorResponse.errors); // تعيين أخطاء التحقق
                } else {
                    throw new Error('Failed to register user: ' + response.status + ' ' + response.statusText);
                }
            } else {
                const data = await response.json();
                console.log('User registered successfully:', data);

                // الانتقال إلى صفحة تسجيل الدخول بعد التسجيل الناجح
                navigate('/login'); // اضبط المسار حسب الحاجة
            }
        } catch (error) {
            console.error('Error:', error);
        }
    };

    return (
        <div className="signup-container">
            <h2>Sign Up</h2>
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label htmlFor="name">Name</label>
                    <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                    />
                    {errors.name && <p className="error-message">{errors.name[0]}</p>}
                </div>
                <div className="form-group">
                    <label htmlFor="email">Email</label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                    />
                    {errors.email && <p className="error-message">{errors.email[0]}</p>}
                </div>
                <div className="form-group">
                    <label htmlFor="password">Password</label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        required
                    />
                    {errors.password && <p className="error-message">{errors.password[0]}</p>}
                </div>
                <div className="form-group">
                    <label htmlFor="phone">Phone</label>
                    <input
                        type="text"
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        required
                    />
                    {errors.phone && <p className="error-message">{errors.phone[0]}</p>}
                </div>
                <div className="form-group">
                    <label htmlFor="address">Address</label>
                    <input
                        type="text"
                        id="address"
                        name="address"
                        value={formData.address}
                        onChange={handleChange}
                        required
                    />
                    {errors.address && <p className="error-message">{errors.address[0]}</p>}
                </div>
                <div className="form-group">
                    <label htmlFor="license_number">License Number</label>
                    <input
                        type="text"
                        id="license_number"
                        name="license_number"
                        value={formData.license_number}
                        onChange={handleChange}
                        required
                    />
                    {errors.license_number && <p className="error-message">{errors.license_number[0]}</p>}
                </div>
                <div className="form-group">
                    <label htmlFor="license_image">License Image URL</label>
                    <input
                        type="url"
                        id="license_image"
                        name="license_image"
                        value={formData.license_image}
                        onChange={handleChange}
                    />
                    {errors.license_image && <p className="error-message">{errors.license_image[0]}</p>}
                </div>
                <button type="submit">Sign Up</button>
            </form>
        </div>
    );
};

export default SignupPage;