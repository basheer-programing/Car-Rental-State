// src/pages/CarDetailsPage.js
import React from 'react';
import { useParams } from 'react-router-dom';
import './css-pages/CarDetailsPage.css';
import { Link } from 'react-router-dom'; // Import Link for navigation
import car1 from '../assets/images/car1.png';
import car2 from '../assets/images/car2.png';
import car3 from '../assets/images/car3.png';



const CarDetailsPage = () => {
    const { carId } = useParams();  // Get the carId from the URL


    const mockCarData = [
        { id: 1, carName: 'Toyota Camry', make: 'Toyota', year: 2021, price: '$30/day', description: 'A reliable family sedan.', image: car1 },
        { id: 2, carName: 'Honda Accord', make: 'Honda', year: 2020, price: '$35/day', description: 'A comfortable ride with modern features.', image: car2 },
        { id: 3, carName: 'BMW 3 Series', make: 'BMW', year: 2021, price: '$50/day', description: 'A luxury sports sedan.', image: car3 },
    ];

    // Find the car that matches the carId
    const car = mockCarData.find(car => car.id === parseInt(carId));

    if (!car) {
        return <div>Car not found!</div>;  // In case the carId is invalid
    }

    return (
        <div className="car-details-page">
            <h1>{car.carName}</h1>
            <div className="car-details">
                <img src={car.image} alt={car.carName} className="car-image" />
                <div className="car-info">
                    <h2>{car.make} {car.carName} ({car.year})</h2>
                    <p><strong>Price per day:</strong> {car.price}</p>
                    <p><strong>Description:</strong> {car.description}</p>
                    <button className="reserve-button"> <Link to="/reservation" className="back-to-reservation-link">Reserve This Car</Link></button>
                </div>
            </div>
        </div>
    );
};

export default CarDetailsPage;
