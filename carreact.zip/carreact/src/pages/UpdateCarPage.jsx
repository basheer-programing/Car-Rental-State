import  { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import './css-pages/AddCarPage.css';

const UpdateCarPage = () => {
    const { carId } = useParams(); // Get carId from URL
    const navigate = useNavigate(); // For navigation after update
    const [carDetails, setCarDetails] = useState({
        model: '',
        year: '',
        color: '',
        features: '',
        seats: '',
        status: '',
        location: '',
        daily_price: '',
        image: '',
    });
    const [errors, setErrors] = useState({}); // State to hold validation errors
    const [isLoading, setIsLoading] = useState(true); // State to track loading

    // Fetch car details when the component mounts
    useEffect(() => {
        const fetchCarDetails = async () => {
            if (!carId) {
                console.error("Car ID is missing!");
                alert("Invalid car ID.");
                navigate("/cars");
                return;
            }
            try {
                const response = await fetch(`http://localhost:8000/api/cars/${carId}`);
                if (!response.ok) {
                    throw new Error('Failed to fetch car details');
                }
                const data = await response.json();
                console.log('API Response:', data); // Debugging: Log the response
                if (data.car) { // Check if car data exists
                    setCarDetails(data.car); // Update state with the response data
                } else {
                    throw new Error('Car data not found');
                }
            } catch (error) {
                console.error('Error:', error.message);
                alert(error.message);
            } finally {
                setIsLoading(false); // Set loading to false after fetching
            }
        };

        fetchCarDetails();
    }, [carId]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setCarDetails((prevDetails) => ({
            ...prevDetails,
            [name]: value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsLoading(true); // Set loading to true when form is submitted

        const carData = {
            model: carDetails.model,
            year: carDetails.year,
            color: carDetails.color,
            features: carDetails.features,
            seats: carDetails.seats,
            status: carDetails.status,
            location: carDetails.location,
            daily_price: carDetails.daily_price,
            image: carDetails.image,
        };

        try {
            const response = await fetch(`http://localhost:8000/api/cars/${carId}`, {
                method: 'PUT', // Use PUT or PATCH for updates
                headers: {
                    'Content-Type': 'application/json',
                     "Authorization": `Bearer ${localStorage.getItem("token")}`
                },
                body: JSON.stringify(carData), // Send as JSON
            });

            if (!response.ok) {
                const errorData = await response.json();
                if (errorData.errors) {
                    setErrors(errorData.errors); // Set validation errors
                }
                throw new Error(errorData.message || 'Failed to update car');
            }

            const data = await response.json();
            alert(data.message); // Show success message
            setCarDetails(data.car);
            console.log('Car updated:', data.car);
            setErrors({}); // Clear errors on success

            // Redirect to the cars list page after successful update
            navigate('/cars');
        } catch (error) {
            console.error('Error:', error.message);
            alert(error.message); // Show error message
        } finally {
            setIsLoading(false); // Set loading to false after submission is complete
        }
    };

    if (isLoading) {
        return <p className="loading-message">Loading car details...</p>;
    }

    if (!carDetails.id) {
        return <p className="error-message">Car not found.</p>;
    }

    return (
        <div className="add-car-page">
            <h1 className="newhh">Update Car</h1>
            <form className="add-car-form" onSubmit={handleSubmit}>
                {/* Model Input */}
                <input
                    type="text"
                    name="model"
                    placeholder="Car Model"
                    defaultValue={carDetails.model || ''}
                    onChange={handleInputChange}
                    className="input-field"
                    required
                />
                {errors.model && <p className="error">{errors.model[0]}</p>}

                      {/* Year Input */}
                      <input
                    type="number"
                    name="year"
                    placeholder="Year"
                    value={carDetails.year || ''}
                    onChange={handleInputChange}
                    className="input-field"
                    required
                />
                {errors.year && <p className="error">{errors.year[0]}</p>}

                {/* Color Input */}
                <input
                    type="text"
                    name="color"
                    placeholder="Color"
                    value={carDetails.color || ''}
                    onChange={handleInputChange}
                    className="input-field"
                    required
                />
                {errors.color && <p className="error">{errors.color[0]}</p>}

                {/* Features Input */}
                <textarea
                    name="features"
                    placeholder="Features (comma-separated)"
                    value={carDetails.features || ''}
                    onChange={handleInputChange}
                    className="input-field"
                    rows="3"
                    required
                />
                {errors.features && <p className="error">{errors.features[0]}</p>}

                {/* Seats Input */}
                <input
                    type="number"
                    name="seats"
                    placeholder="Number of Seats"
                    value={carDetails.seats || ''}
                    onChange={handleInputChange}
                    className="input-field"
                    required
                />
                {errors.seats && <p className="error">{errors.seats[0]}</p>}

                {/* Status Input */}
                <input
                    type="text"
                    name="status"
                    placeholder="Status"
                    value={carDetails.status || ''}
                    onChange={handleInputChange}
                    className="input-field"
                    required
                />
                {errors.status && <p className="error">{errors.status[0]}</p>}

                {/* Location Input */}
                <input
                    type="text"
                    name="location"
                    placeholder="Location"
                    value={carDetails.location || ''}
                    onChange={handleInputChange}
                    className="input-field"
                    required
                />
                {errors.location && <p className="error">{errors.location[0]}</p>}

                {/* Daily Price Input */}
                <input
                    type="number"
                    name="daily_price"
                    placeholder="Daily Price"
                    value={carDetails.daily_price || ''}
                    onChange={handleInputChange}
                    className="input-field"
                    required
                />
                {errors.daily_price && <p className="error">{errors.daily_price[0]}</p>}

                {/* Image Input */}
                <input
                    type="text"
                    name="image"
                    placeholder="Image URL"
                    value={carDetails.image || ''}
                    onChange={handleInputChange}
                    className="input-field"
                />
                {errors.image && <p className="error">{errors.image[0]}</p>}

                {/* Submit Button */}
                <button type="submit" className="submit-button" disabled={isLoading}>
                    {isLoading ? 'Updating Car...' : 'Update Car'}
                </button>
            </form>
        </div>
      
    );
};

export default UpdateCarPage;