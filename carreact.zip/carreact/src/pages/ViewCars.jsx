import  { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate
import './css-pages/ViewCars.css';

const ViewCars = () => {
    const [search, setSearch] = useState('');
    const [filter, setFilter] = useState('');
    const [year, setYear] = useState('');
    const [location, setLocation] = useState('');
    const [cars, setCars] = useState([]); // State to store fetched cars
    const [isLoading, setIsLoading] = useState(true); // State to track loading
    const [error, setError] = useState(null); // State to handle errors
    const navigate = useNavigate(); // Initialize useNavigate

    // Fetch cars from the API
    useEffect(() => {
        const fetchCars = async () => {
            try {
                const response = await fetch('http://localhost:8000/api/cars');
                if (!response.ok) {
                    throw new Error('Failed to fetch cars');
                }
                const result = await response.json();
                setCars(result.data); // Assuming the response is { data: [...] }
            } catch (error) {
                setError(error.message);
            } finally {
                setIsLoading(false);
            }
        };

        fetchCars();
    }, []); // Empty dependency array ensures this runs only once on mount

    // Function to handle car deletion
    const handleDelete = async (id) => {
        try {
            const response = await fetch(`http://localhost:8000/api/cars/${id}`, {
                method: 'DELETE',
            });
            if (!response.ok) {
                throw new Error('Failed to delete car');
            }
            // Remove the deleted car from the state
            setCars(cars.filter((car) => car.id !== id));
        } catch (error) {
            setError(error.message);
        }
    };

    // Function to handle car update (redirect to update page)
    const handleUpdate = (id) => {
        navigate(`/cars/update/${id}`); // Redirect to UpdateCarPage with car ID
    };

    // Filter cars based on search, filter, year, and location
    const filteredCars = cars.filter((car) => {
        const matchesSearch = car.model.toLowerCase().includes(search.toLowerCase());
        const matchesStatus = filter ? car.status === filter : true;
        const matchesYear = year ? car.year.toString() === year : true;
        const matchesLocation = location ? car.location.toLowerCase() === location.toLowerCase() : true;
        return matchesSearch && matchesStatus && matchesYear && matchesLocation;
    });

    if (isLoading) {
        return <p className="loading-message">Loading cars...</p>;
    }

    if (error) {
        return <p className="error-message">Error: {error}</p>;
    }

    return (
        <div className="view-cars-page">
            <h1 className="newh11">Available Cars</h1>
            <div className="filter-container">
                <input
                    type="text"
                    placeholder="Search by model..."
                    className="search-input"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />
                <select
                    className="filter-dropdown"
                    value={filter}
                    onChange={(e) => setFilter(e.target.value)}
                >
                    <option value="">All Statuses</option>
                    <option value="Available">Available</option>
                    <option value="Rented">Rented</option>
                    <option value="Under-Maintenance">Under Maintenance</option>
                </select>
                <input
                    type="number"
                    placeholder="Enter Year"
                    className="year-input"
                    value={year}
                    onChange={(e) => setYear(e.target.value)}
                />
                <input
                    type="text"
                    placeholder="Enter Location"
                    className="location-input"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                />
            </div>
            <div className="cars-container">
                {filteredCars.length > 0 ? (
                    filteredCars.map((car) => (
                        <div className="car-card" key={car.id}>
                            <img src={car.photo} alt={car.model} className="car-photo" />
                            <div className="car-details">
                                <h2>{car.model}</h2>
                                <p>Year: {car.year}</p>
                                <p>Location: {car.location}</p>
                                <p>Price: ${car.price}/day</p>
                                <p>Status: <span className={`status ${car.status.toLowerCase()}`}>{car.status}</span></p>
                                <div className="car-actions">
                                    <button
                                        className="update-button"
                                        onClick={() => handleUpdate(car.id)}
                                    >
                                        Update
                                    </button>
                                    <button
                                        className="delete-button"
                                        onClick={() => handleDelete(car.id)}
                                    >
                                        Delete
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))
                ) : (
                    <p className="no-cars-message">No cars found matching the criteria.</p>
                )}
            </div>
        </div>
    );
};

export default ViewCars;