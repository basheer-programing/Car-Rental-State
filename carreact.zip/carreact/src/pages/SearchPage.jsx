import React, { useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './css-pages/SearchPage.css';

const SearchPage = () => {
    const [searchQuery, setSearchQuery] = useState({
        model: '',
        year: '',
        color: '',
        status: '',
        location: '',
        seats: '',
        features: ''
    });
    const [results, setResults] = useState([]);
    const [error, setError] = useState('');

    const handleSearchChange = (e) => {
        const { name, value } = e.target;
        setSearchQuery({ ...searchQuery, [name]: value });
    };

    const handleSearchSubmit = async (e) => {
        e.preventDefault();
        setError('');

        try {
            // إرسال طلب البحث إلى API
            const response = await axios.get('http://127.0.0.1:8000/api/cars', {
                params: searchQuery
            });

            if (response.data.data.length === 0) {
                setError('No cars found matching your search criteria.');
            } else {
                setResults(response.data.data);
            }
        } catch (error) {
            console.error('Error fetching cars:', error);
            setError('Failed to fetch cars. Please try again later.');
        }
    };

    return (
        <div className="search-page-container">
            <h2>Search for a Car</h2>
            <form onSubmit={handleSearchSubmit} className="search-form">
                <input
                    type="text"
                    name="model"
                    placeholder="Model"
                    value={searchQuery.model}
                    onChange={handleSearchChange}
                    className="search-input"
                />
                <input
                    type="text"
                    name="year"
                    placeholder="Year"
                    value={searchQuery.year}
                    onChange={handleSearchChange}
                    className="search-input"
                />
                <input
                    type="text"
                    name="color"
                    placeholder="Color"
                    value={searchQuery.color}
                    onChange={handleSearchChange}
                    className="search-input"
                />
                <input
                    type="text"
                    name="status"
                    placeholder="Status"
                    value={searchQuery.status}
                    onChange={handleSearchChange}
                    className="search-input"
                />
                <input
                    type="text"
                    name="location"
                    placeholder="Location"
                    value={searchQuery.location}
                    onChange={handleSearchChange}
                    className="search-input"
                />
                <input
                    type="text"
                    name="seats"
                    placeholder="Seats"
                    value={searchQuery.seats}
                    onChange={handleSearchChange}
                    className="search-input"
                />
                <input
                    type="text"
                    name="features"
                    placeholder="Features"
                    value={searchQuery.features}
                    onChange={handleSearchChange}
                    className="search-input"
                />
                <button type="submit" className="search-button">Search</button>
            </form>

            {error && <p className="error-message">{error}</p>}

            <div className="search-results">
                {results.map(car => (
                    <div key={car.id} className="car-item">
                        <h3>{car.model}</h3>
                        <p>Year: {car.year}</p>
                        <p>Color: {car.color}</p>
                        <p>Status: {car.status}</p>
                        <p>Location: {car.location}</p>
                        <p>Seats: {car.seats}</p>
                        <p>Features: {car.features}</p>
                        <Link to={`/car/${car.id}`} className="view-details-link">View Details</Link>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default SearchPage;