import  { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom'; // استخدم useParams لاستخراج الـ ID
import axios from 'axios';
import './css-pages/PaymentPage.css';

const PaymentPage = () => {
    const { bookingId } = useParams(); // جلب booking_id من الـ URL
    const [amount, setAmount] = useState('');
    const [paymentMethod, setPaymentMethod] = useState('Credit Card');
    const [statusMessage, setStatusMessage] = useState('');
    const [loading, setLoading] = useState(true);

    //  جلب بيانات الحجز من API للحصول على المبلغ
    useEffect(() => {
        if (!bookingId) return;
        
        axios.get(`http://localhost:8000/api/bookings/${bookingId}`)
            .then(response => {
                setAmount(response.data.amount); // استخراج المبلغ من الـ API
                setLoading(false);
            })
            .catch(error => {
                console.error('Error fetching booking data:', error);
                setLoading(false);
            });
    }, [bookingId]);

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await axios.post('http://localhost:8000/api/payments', {
                booking_id: bookingId, 
                amount: parseFloat(amount), 
                payment_method: paymentMethod,
                status: 'pending'
            });

            setStatusMessage('Payment successful!');
            setAmount('');
        } catch (error) {
            setStatusMessage('Payment failed. Please try again.');
            console.error('Payment error:', error.response?.data);
        }
    };

    if (loading) {
        return <p>Loading payment details...</p>;
    }

    return (
        <div className="payment-page">
            <h1>Payment Page</h1>
            <p>Please enter your payment details to complete the reservation.</p>
            
            <form onSubmit={handleSubmit} className="payment-form">
                <div className="form-group">
                    <label htmlFor="amount">Amount</label>
                    <input 
                        type="number" 
                        id="amount" 
                        value={amount} 
                        onChange={(e) => setAmount(e.target.value)} 
                        placeholder="Enter amount" 
                        required
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="paymentMethod">Payment Method</label>
                    <select 
                        id="paymentMethod" 
                        value={paymentMethod} 
                        onChange={(e) => setPaymentMethod(e.target.value)} 
                        required
                    >
                        <option value="Credit Card">Credit Card</option>
                        <option value="PayPal">PayPal</option>
                        <option value="Bank Transfer">Bank Transfer</option>
                    </select>
                </div>

                <div className="form-group">
                    <button type="submit" className="submit-btn">Complete Payment</button>
                </div>
            </form>

            {statusMessage && <p className="status-message">{statusMessage}</p>}

            <div className="payment-links">
                <Link to="/reservation" className="back-to-reservation-link">Back to Reservation</Link>
                <Link to="/" className="back-to-home-link">Back to Home</Link>
            </div>
        </div>
    );
};

export default PaymentPage;
