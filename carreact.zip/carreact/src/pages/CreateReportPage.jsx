import  { useState } from 'react';
import './css-pages/CreateReportPage.css';

const CreateReportPage = () => {
  const [formData, setFormData] = useState({
    reportName: '',
    dateRange: '',
    revenue: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Report Data Submitted: ', formData);
    // Add functionality to handle form submission (e.g., API call to save data)
  };

  return (
    <div className="create-report-container">
      <h1>Create Rental Revenue Report</h1>
      <p>Fill in the details below to create a new rental revenue report.</p>

      <form className="report-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="reportName">Report Name</label>
          <input
            type="text"
            id="reportName"
            name="reportName"
            value={formData.reportName}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="dateRange">Date Range</label>
          <input
            type="text"
            id="dateRange"
            name="dateRange"
            value={formData.dateRange}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="revenue">Revenue</label>
          <input
            type="number"
            id="revenue"
            name="revenue"
            value={formData.revenue}
            onChange={handleChange}
            required
          />
        </div>

        <button type="submit" className="submit-btn">Create Report</button>
      </form>
    </div>
  );
};

export default CreateReportPage;
