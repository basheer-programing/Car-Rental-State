// FeedbackPage Component 
// src/pages/FeedbackPage.js
import  { useState } from 'react';
import './css-pages/FeedbackPage.css';

const FeedbackPage = () => {
    const [feedback, setFeedback] = useState('');

    const handleFeedbackChange = (e) => {
        setFeedback(e.target.value);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        alert(`Feedback submitted: ${feedback}`);
        // Here you can handle the submission to the backend
    };

    return (
        <div className="feedback-page">
            <h1>Feedback Page</h1>
            <p>We value your feedback! Please leave your comments below:</p>
            
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label htmlFor="feedback">Your Feedback</label>
                    <textarea
                        id="feedback"
                        value={feedback}
                        onChange={handleFeedbackChange}
                        rows="5"
                        placeholder="Write your feedback here"
                    />
                </div>

                <div className="form-group">
                    <button type="submit">Submit Feedback</button>
                </div>
            </form>
        </div>
    );
};

export default FeedbackPage;
