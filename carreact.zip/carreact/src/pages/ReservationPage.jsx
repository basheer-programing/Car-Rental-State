import { useState } from 'react';
import './css-pages/ReservationPage.css';
import { Link } from 'react-router-dom';
import axios from 'axios';

const ReservationPage = () => {
    const [carId, setCarId] = useState('1'); // استخدام الـ id الصحيح للسيارة
    const [pickUpDate, setPickUpDate] = useState('');
    const [returnDate, setReturnDate] = useState('');
    const [location, setLocation] = useState('Damascus');
    const [bookingId, setBookingId] = useState(null); // لتخزين ID الحجز بعد نجاحه
    const [reservationConfirmed, setReservationConfirmed] = useState(false);

    // محاكاة الحصول على `user_id` (يجب استبداله بجلب البيانات الفعلية)
    const userId = 1;

    // إرسال بيانات الحجز إلى API
    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!pickUpDate || !returnDate) {
            alert("يرجى تحديد تواريخ الحجز.");
            return;
        }

        try {
            // 1. إنشاء الحجز
            const res = await axios.post("http://localhost:8000/api/bookings", {
                user_id: userId,
                car_id: carId,
                start_date: pickUpDate,
                end_date: returnDate,
                location: location
            }, {
                headers: { "Content-Type": "application/json" }
            });

            console.log("تم حجز السيارة بنجاح:", res.data);
            setBookingId(res.data.booking.id); // حفظ ID الحجز
            setReservationConfirmed(true);

            // 2. تحديث حالة السيارة إلى "غير متاحة"
            await axios.patch(`http://localhost:8000/api/cars/${carId}`, {
                status: 'غير متاحة'
            }, {
                headers: { "Content-Type": "application/json" }
            });

            alert("تم حجز السيارة وتحديث حالتها بنجاح!");
        } catch (err) {
            console.error("خطأ في الحجز:", err.response ? err.response.data : err.message);
            alert("حدث خطأ أثناء الحجز. يرجى المحاولة مرة أخرى.");
        }
    };

    return (
        <div className="reservation-page">
            <h1>Reservation Page</h1>
            <p>Here you can make, modify, or cancel your car rental reservation.</p>
            
            <form onSubmit={handleSubmit} className="reservation-form">
                <div className="form-group">
                    <label htmlFor="carId">Car Model</label>
                    <select 
                        id="carId" 
                        value={carId} 
                        onChange={(e) => setCarId(e.target.value)} 
                        required
                    >
                        <option value="1">Sedan</option>
                        <option value="2">SUV</option>
                        <option value="3">Truck</option>
                        <option value="4">Convertible</option>
                    </select>
                </div>

                <div className="form-group">
                    <label htmlFor="pickUpDate">Pick-Up Date</label>
                    <input 
                        type="date" 
                        id="pickUpDate" 
                        value={pickUpDate} 
                        onChange={(e) => setPickUpDate(e.target.value)} 
                        required
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="returnDate">Return Date</label>
                    <input 
                        type="date" 
                        id="returnDate" 
                        value={returnDate} 
                        onChange={(e) => setReturnDate(e.target.value)} 
                        required
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="location">Location</label>
                    <input 
                        type="text" 
                        id="location" 
                        value={location} 
                        onChange={(e) => setLocation(e.target.value)} 
                        required
                    />
                </div>

                {!reservationConfirmed ? (
                    <div className="form-group">
                        <button type="submit" className="submit-btn">Reserve Now</button>
                    </div>
                ) : (
                    <div className="reservation-summary">
                        <h3>Reservation Confirmed!</h3>
                        <p><strong>Car ID:</strong> {carId}</p>
                        <p><strong>Pick-Up Date:</strong> {pickUpDate}</p>
                        <p><strong>Return Date:</strong> {returnDate}</p>
                        <p><strong>Location:</strong> {location}</p>
                    </div>
                )}

                <div className="form-group">
                    {bookingId ? (
                        <Link to={`/payment/${bookingId}`} className="proceed-to-payment-btn">
                            Proceed to Payment
                        </Link>
                    ) : null}
                </div>
            </form>
        </div>
    );
};

export default ReservationPage;