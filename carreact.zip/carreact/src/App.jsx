// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { AuthProvider } from './components/context/AuthContext';
import { ReservationProvider } from './components/context/ReservationContext';
import Navbar from './components/Navbar/Navbar';
import Footer from './components/Footer/Footer';
import Homepage from './pages/Homepage';
import SearchPage from './pages/SearchPage';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import ReservationPage from './pages/ReservationPage';
import PaymentPage from './pages/PaymentPage';
import FeedbackPage from './pages/FeedbackPage';
import CarDetailsPage from './pages/CarDetailsPage';  // Add CarDetailsPage import
import AdminDashboard from './pages/AdminDashboard';
import AddCarPage from './pages/AddCarPage';
import ViewCars from './pages/ViewCars';
import ManageRentalsPage from './pages/ManageRentalsPage';
import ManageCustomersPage from "./pages/ManageCustomersPage";
import About from "./pages/About";
import Contact from "./pages/Contact";
import ReportsPage from './pages/ReportsPage';
import CreateReportPage from './pages/CreateReportPage';
import  UpdateCarPage from './pages/UpdateCarPage';
const App = () => {
    return (
        <AuthProvider>
            <ReservationProvider>
                <Router>
                    <Navbar />
                    <main>
                        <Routes>
                            <Route path="/" element={<Homepage />} />
                            <Route path="/admin" element={<AdminDashboard />} />
                            <Route path="/search" element={<SearchPage />} />
                            <Route path="/login" element={<LoginPage />} />
                            <Route path="/signup" element={<SignupPage />} />
                            <Route path="/reservation" element={<ReservationPage />} />
                            <Route path="/payment/:bookingId" element={<PaymentPage />} />
                            <Route path="/feedback" element={<FeedbackPage />} />
                            <Route path="/car/:carId" element={<CarDetailsPage />} /> {/* Dynamic route for car details */}
                            <Route path="/add-car" element={<AddCarPage />} />
                            <Route path="/view-cars" element={<ViewCars />} />
                            <Route path="/manage-rentals" element={<ManageRentalsPage />} />
                            <Route path="/manage-customers" element={<ManageCustomersPage />} />
                            <Route path="/about" element={<About />} />
                            <Route path="/contact" element={<Contact />} />
                            <Route path="/reports" element={<ReportsPage />} /> 
                            <Route path="/create-report" element={<CreateReportPage />} />
                            <Route path="/cars/update/:carId" element={<UpdateCarPage />} />

                        </Routes>
                    </main>
                    <Footer />
                </Router>
            </ReservationProvider>
        </AuthProvider>
    );
};

export default App;
