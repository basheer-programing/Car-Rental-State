// Entry Point 
import React from 'react';
import ReactDOM from 'react-dom/client';  // React 18 uses 'react-dom/client' for root rendering
import './index.css';  // Import your global CSS file
  import App from './App'; 
  // Import the main App component
// import Testapi from './testlaravel';
// Render the App component into the root div of your HTML file
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <>
    <App/>
  </>
);
