// API Service 
// src/services/api.js

import axios from 'axios';

// Base URL for the API
const API_BASE_URL = 'https://your-api-endpoint.com/api'; // Replace with your API base URL

// Create an Axios instance
const apiClient = axios.create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
});

// Example: Get all cars
export const getAllCars = async () => {
    try {
        const response = await apiClient.get('/cars');
        return response.data;
    } catch (error) {
        console.error('Error fetching cars:', error);
        throw error;
    }
};

// Example: Get car by ID
export const getCarById = async (carId) => {
    try {
        const response = await apiClient.get(`/cars/${carId}`);
        return response.data;
    } catch (error) {
        console.error(`Error fetching car with ID ${carId}:`, error);
        throw error;
    }
};

// Example: Submit feedback
export const submitFeedback = async (feedbackData) => {
    try {
        const response = await apiClient.post('/feedback', feedbackData);
        return response.data;
    } catch (error) {
        console.error('Error submitting feedback:', error);
        throw error;
    }
};

// Example: Create a reservation
export const createReservation = async (reservationData) => {
    try {
        const response = await apiClient.post('/reservations', reservationData);
        return response.data;
    } catch (error) {
        console.error('Error creating reservation:', error);
        throw error;
    }
};

// Example: Get reservations
export const getAllReservations = async () => {
    try {
        const response = await apiClient.get('/reservations');
        return response.data;
    } catch (error) {
        console.error('Error fetching reservations:', error);
        throw error;
    }
};

// Add other API functions as needed...
