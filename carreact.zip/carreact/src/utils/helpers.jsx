// Utility Helpers 
// src/utils/helpers.js

/**
 * Format a date to a readable string.
 * @param {string | Date} date - The date to format.
 * @returns {string} - Formatted date string.
 */
export const formatDate = (date) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(date).toLocaleDateString(undefined, options);
};

/**
 * Capitalize the first letter of a string.
 * @param {string} str - The input string.
 * @returns {string} - String with the first letter capitalized.
 */
export const capitalizeFirstLetter = (str) => {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
};

/**
 * Format a price to include a currency symbol.
 * @param {number} price - The price amount.
 * @param {string} currencySymbol - The currency symbol (default: $).
 * @returns {string} - Formatted price string.
 */
export const formatPrice = (price, currencySymbol = '$') => {
    return `${currencySymbol}${price.toFixed(2)}`;
};

/**
 * Truncate a string to a specific length, adding ellipsis if needed.
 * @param {string} str - The input string.
 * @param {number} maxLength - The maximum length of the string.
 * @returns {string} - Truncated string.
 */
export const truncateString = (str, maxLength) => {
    if (str.length <= maxLength) return str;
    return `${str.slice(0, maxLength)}...`;
};

/**
 * Generate a random ID.
 * @returns {string} - Random ID string.
 */
export const generateRandomId = () => {
    return Math.random().toString(36).substr(2, 9);
};
