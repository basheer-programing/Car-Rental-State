import  { useEffect, useState } from 'react';

function Testapi() {
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    fetch('http://localhost:8000/api/example')
      .then((response) => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then((data) => setMessage(data.message))
      .catch((error) => {
        console.error('Error fetching data:', error);
        setError('Failed to fetch data from the server.');
      });
  }, []);

  return (
    <div className="App">
      <h1>React and Laravel Example</h1>
      {error ? (
        <p style={{ color: 'red' }}>{error}</p>
      ) : (
        <p>Message from Laravel: {message}</p>
      )}
    </div>
  );
}

export default Testapi;