import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext'; // Import useAuth
import './Navbar.css';

const Navbar = () => {
    const { isAuthenticated, userId, logout } = useAuth(); // Get userId and authentication state

    return (
        <nav className="navbar">
            <div className="navbar-logo">
                <Link to="/">Car Rental</Link>
            </div>
            <ul className="navbar-links">
                <li><Link to="/">Home</Link></li>
                <li><Link to="/admin" className="navbar-link">Admin Dashboard</Link></li>
                <li><Link to="/search">Search</Link></li>
                <li><Link to="/about">About</Link></li>
                <li><Link to="/contact">Contact</Link></li>
                {isAuthenticated ? (
                    <>
                        <li><Link to="/reservation" className="reservation">Reservation</Link></li>
                        <li><Link to="/feedback" className="navbar-feedback">Feedback</Link></li>
                        <li>
                            <button onClick={logout} className="navbar-logout">Logout</button>
                        </li>
                    </>
                ) : (
                    <>
                        <li><Link to="/login" className="navbar-login">Login</Link></li>
                        <li><Link to="/signup" className="navbar-signup">Sign Up</Link></li>
                    </>
                )}
            </ul>
        </nav>
    );
};

export default Navbar;