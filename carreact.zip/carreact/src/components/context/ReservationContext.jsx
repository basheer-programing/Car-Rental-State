// Reservation Context 
import  { createContext, useState, useContext } from 'react';

// Create the Reservation Context
const ReservationContext = createContext();

// ReservationProvider Component
export const ReservationProvider = ({ children }) => {
    const [reservationDetails, setReservationDetails] = useState({
        car: null,
        startDate: null,
        endDate: null,
        location: null,
    });

    // Function to update reservation details
    const updateReservation = (details) => {
        setReservationDetails((prev) => ({ ...prev, ...details }));
    };

    // Function to reset reservation details
    const resetReservation = () => {
        setReservationDetails({
            car: null,
            startDate: null,
            endDate: null,
            location: null,
        });
    };

    return (
        <ReservationContext.Provider value={{ reservationDetails, updateReservation, resetReservation }}>
            {children}
        </ReservationContext.Provider>
    );
};

// Custom Hook for using ReservationContext
export const useReservation = () => {
    return useContext(ReservationContext);
};
